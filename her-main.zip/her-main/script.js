document.getElementById('revealButton').addEventListener('click', function() {
    document.getElementById('proposalMessage').classList.remove('hidden');
});
